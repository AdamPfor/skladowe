package InneKlasy;

public class Sklep {
    private String adres;
    protected double powierzchnia;
    private boolean czyJestWc;
    private double czynsz;

    public Sklep(String adres, double powierzchnia, boolean czyJestWc, double czynsz) {
        this.adres = adres;
        this.powierzchnia = powierzchnia;
        this.czyJestWc = czyJestWc;
        this.czynsz = czynsz;
    }

    @Override
    public String toString() {
        return "Adres sklepu: " + adres + ", powierzchnia lokalu: " + powierzchnia + "m^2, czy jest WC: " + czyJestWc + ", czynsz najmu: " + czynsz + "zł/miesiąc";
    }

    public int liczbaPolkek() {
        return (int) (powierzchnia / 2);
    }

    public final double obliczCzynsz(int liczbaMiesiecy) {
        return czynsz * liczbaMiesiecy;
    }


}
