package InneKlasy;

public class Kwiaciarnia extends Sklep {
    private double powierzchniaZaplecza;

    public Kwiaciarnia(String adres, double powierzchnia, boolean czyJestWc, double czynsz, double powierzchniaZaplecza) {
        super(adres, powierzchnia, czyJestWc, czynsz);
        this.powierzchniaZaplecza = powierzchniaZaplecza;
    }

    @Override
    public String toString() {
        return super.toString() + ", powierzchnia zaplecza: " + powierzchniaZaplecza;
    }

    @Override
    public int liczbaPolkek() {
        double powierzchniaCalkowita = powierzchnia + powierzchniaZaplecza;
        int liczbaPolkek = (int) (powierzchniaCalkowita / 4);
        return liczbaPolkek;
    }
}
